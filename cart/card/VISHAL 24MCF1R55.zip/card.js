
document.addEventListener('DOMContentLoaded', function() {
    // Get references to the stock count and buttons
    let stockCountElement = document.getElementById('count');
    let buyButton = document.querySelector('.buy');
    let cartButton = document.querySelector('.cart');

    // Get the initial stock count as a number
    let stockCount = parseInt(stockCountElement.textContent);

    // Function to decrease stock count
    function reduceStock() {
        if (stockCount > 0) {
            stockCount--;
            stockCountElement.textContent = stockCount;
        } else {
            // Show an alert when stock is 0
            alert('Out of stock!');
        }
    }

    // Add event listeners to the buttons
    buyButton.addEventListener('click', reduceStock);
    cartButton.addEventListener('click', reduceStock);
});
